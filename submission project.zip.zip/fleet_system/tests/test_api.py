"""
Unit tests for Fleet Management System.
Run: pytest tests/ -v --cov=app --cov-report=term-missing
"""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.main import app
from app.db.database import Base, get_db
from app.core.security import hash_password

# ─── In-memory SQLite test database ──────────────────────────────────────────
TEST_DB_URL = "sqlite:///./test_fleet.db"
engine = create_engine(TEST_DB_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db


@pytest.fixture(scope="module", autouse=True)
def setup_db():
    """Create tables and seed minimal test data."""
    from app.models import user, vehicle, route, trip, alert  # noqa
    Base.metadata.create_all(bind=engine)
    db = TestingSessionLocal()

    from app.models.user import User, UserRole
    from app.models.vehicle import Vehicle, VehicleType, FuelStatus, MaintenanceStatus
    from app.models.route import Route

    # Seed admin
    admin = User(full_name="Test Admin", email="admin@test.com",
                 hashed_password=hash_password("Admin@1234"), role=UserRole.admin)
    dispatcher = User(full_name="Test Dispatcher", email="dispatcher@test.com",
                      hashed_password=hash_password("Admin@1234"), role=UserRole.dispatcher)
    driver = User(full_name="Test Driver", email="driver@test.com",
                  hashed_password=hash_password("Admin@1234"), role=UserRole.driver)

    vehicle = Vehicle(vehicle_id="TRK-TEST", registration_number="TEST-001",
                      vehicle_type=VehicleType.truck, capacity=10,
                      fuel_level=80.0, fuel_status=FuelStatus.full,
                      maintenance_status=MaintenanceStatus.good, is_available=True)
    route = Route(route_code="RT-TEST", name="Test Route",
                  origin="CityA", destination="CityB",
                  distance_km=100.0, estimated_duration_hours=2.0)

    db.add_all([admin, dispatcher, driver, vehicle, route])
    db.commit()
    db.close()
    yield
    Base.metadata.drop_all(bind=engine)


@pytest.fixture(scope="module")
def client():
    return TestClient(app)


@pytest.fixture(scope="module")
def admin_token(client):
    r = client.post("/api/auth/login", json={"email": "admin@test.com", "password": "Admin@1234"})
    assert r.status_code == 200
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def dispatcher_token(client):
    r = client.post("/api/auth/login", json={"email": "dispatcher@test.com", "password": "Admin@1234"})
    assert r.status_code == 200
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def driver_token(client):
    r = client.post("/api/auth/login", json={"email": "driver@test.com", "password": "Admin@1234"})
    assert r.status_code == 200
    return r.json()["access_token"]


# ─── Auth Tests ───────────────────────────────────────────────────────────────

class TestAuth:
    def test_login_success(self, client):
        r = client.post("/api/auth/login", json={"email": "admin@test.com", "password": "Admin@1234"})
        assert r.status_code == 200
        data = r.json()
        assert "access_token" in data
        assert "refresh_token" in data
        assert data["token_type"] == "bearer"

    def test_login_wrong_password(self, client):
        r = client.post("/api/auth/login", json={"email": "admin@test.com", "password": "WrongPass"})
        assert r.status_code == 401

    def test_login_unknown_email(self, client):
        r = client.post("/api/auth/login", json={"email": "nobody@test.com", "password": "pass"})
        assert r.status_code == 401

    def test_get_me(self, client, admin_token):
        r = client.get("/api/auth/me", headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200
        assert r.json()["email"] == "admin@test.com"
        assert r.json()["role"] == "admin"

    def test_register_requires_admin(self, client, driver_token):
        r = client.post("/api/auth/register",
                        json={"full_name": "New User", "email": "new@test.com",
                              "password": "Pass@1234", "role": "driver"},
                        headers={"Authorization": f"Bearer {driver_token}"})
        assert r.status_code == 403

    def test_register_as_admin(self, client, admin_token):
        r = client.post("/api/auth/register",
                        json={"full_name": "New Driver", "email": "newdriver@test.com",
                              "password": "Pass@1234", "role": "driver"},
                        headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 201
        assert r.json()["role"] == "driver"

    def test_no_token_rejected(self, client):
        r = client.get("/api/vehicles")
        assert r.status_code == 403  # no Bearer header


# ─── Vehicle Tests ────────────────────────────────────────────────────────────

class TestVehicles:
    def test_list_vehicles(self, client, admin_token):
        r = client.get("/api/vehicles", headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200
        data = r.json()
        assert "vehicles" in data
        assert data["total"] >= 1

    def test_create_vehicle(self, client, admin_token):
        r = client.post("/api/vehicles",
                        json={"vehicle_id": "VAN-TEST", "registration_number": "VAN-REG-001",
                              "vehicle_type": "van", "capacity": 8, "fuel_level": 90.0},
                        headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 201
        assert r.json()["vehicle_id"] == "VAN-TEST"
        assert r.json()["fuel_status"] == "full"

    def test_create_duplicate_vehicle(self, client, admin_token):
        r = client.post("/api/vehicles",
                        json={"vehicle_id": "TRK-TEST", "registration_number": "DUP-001",
                              "vehicle_type": "truck", "capacity": 5},
                        headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 400

    def test_get_vehicle_by_id(self, client, admin_token):
        r = client.get("/api/vehicles/1", headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200

    def test_update_vehicle(self, client, admin_token):
        r = client.put("/api/vehicles/1",
                       json={"capacity": 25},
                       headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200
        assert r.json()["capacity"] == 25

    def test_fuel_update(self, client, admin_token):
        r = client.patch("/api/vehicles/1/fuel",
                         json={"fuel_level": 12.0},
                         headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200
        assert r.json()["fuel_status"] == "low"

    def test_driver_cannot_create_vehicle(self, client, driver_token):
        r = client.post("/api/vehicles",
                        json={"vehicle_id": "XX-99", "registration_number": "XX-99",
                              "vehicle_type": "van", "capacity": 3},
                        headers={"Authorization": f"Bearer {driver_token}"})
        assert r.status_code == 403


# ─── Route Tests ──────────────────────────────────────────────────────────────

class TestRoutes:
    def test_list_routes(self, client, admin_token):
        r = client.get("/api/routes", headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200
        assert r.json()["total"] >= 1

    def test_create_route(self, client, admin_token):
        r = client.post("/api/routes",
                        json={"route_code": "RT-NEW-001", "name": "New Route",
                              "origin": "Delhi", "destination": "Mumbai",
                              "distance_km": 1400.0, "estimated_duration_hours": 22.0},
                        headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 201
        assert r.json()["route_code"] == "RT-NEW-001"


# ─── Trip Tests ───────────────────────────────────────────────────────────────

class TestTrips:
    _trip_id = None

    def test_create_trip(self, client, dispatcher_token):
        from datetime import datetime, timezone, timedelta
        now = datetime.now(timezone.utc)
        r = client.post("/api/trips",
                        json={
                            "vehicle_id": 1, "driver_id": 3, "route_id": 1,
                            "scheduled_departure": (now + timedelta(hours=1)).isoformat(),
                            "scheduled_arrival": (now + timedelta(hours=10)).isoformat(),
                            "cargo_description": "Test cargo",
                        },
                        headers={"Authorization": f"Bearer {dispatcher_token}"})
        assert r.status_code == 201
        TestTrips._trip_id = r.json()["id"]
        assert r.json()["status"] == "scheduled"

    def test_list_trips(self, client, admin_token):
        r = client.get("/api/trips", headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200

    def test_status_transition_to_in_progress(self, client, dispatcher_token):
        r = client.patch(f"/api/trips/{TestTrips._trip_id}/status",
                         json={"status": "in_progress"},
                         headers={"Authorization": f"Bearer {dispatcher_token}"})
        assert r.status_code == 200
        assert r.json()["status"] == "in_progress"
        assert r.json()["actual_departure"] is not None

    def test_invalid_status_transition(self, client, dispatcher_token):
        # Can't go from in_progress back to scheduled
        r = client.patch(f"/api/trips/{TestTrips._trip_id}/status",
                         json={"status": "scheduled"},
                         headers={"Authorization": f"Bearer {dispatcher_token}"})
        assert r.status_code == 400

    def test_status_transition_to_completed(self, client, dispatcher_token):
        r = client.patch(f"/api/trips/{TestTrips._trip_id}/status",
                         json={"status": "completed", "fuel_used_liters": 45.0,
                               "distance_covered_km": 100.0},
                         headers={"Authorization": f"Bearer {dispatcher_token}"})
        assert r.status_code == 200
        assert r.json()["status"] == "completed"

    def test_trip_logs_captured(self, client, admin_token):
        r = client.get(f"/api/trips/{TestTrips._trip_id}/logs",
                       headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200
        assert len(r.json()) >= 2  # TRIP_CREATED + STATUS_CHANGED × 2


# ─── Alert Tests ──────────────────────────────────────────────────────────────

class TestAlerts:
    def test_create_alert(self, client, driver_token):
        r = client.post("/api/alerts",
                        json={"alert_type": "breakdown", "severity": "high",
                              "vehicle_id": 1, "message": "Engine making strange noise"},
                        headers={"Authorization": f"Bearer {driver_token}"})
        assert r.status_code == 201
        assert r.json()["is_resolved"] == False

    def test_resolve_alert(self, client, admin_token):
        r = client.patch("/api/alerts/1/resolve",
                         json={"resolution_note": "Mechanic dispatched and issue fixed"},
                         headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200
        assert r.json()["is_resolved"] == True

    def test_fleet_summary(self, client, admin_token):
        r = client.get("/api/reports/fleet-summary",
                       headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200
        data = r.json()
        assert "total_vehicles" in data
        assert "open_alerts" in data

    def test_daily_performance(self, client, admin_token):
        r = client.get("/api/reports/daily-performance",
                       headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200
        data = r.json()
        assert "total_trips" in data
        assert "on_time_percentage" in data
