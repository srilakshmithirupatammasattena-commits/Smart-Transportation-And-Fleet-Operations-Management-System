from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session
from typing import Optional
from datetime import date

from app.db.database import get_db
from app.models.alert import AlertSeverity
from app.schemas.alert import (
    AlertCreate, AlertResolve, AlertResponse, AlertListResponse,
    FleetSummaryReport, TripPerformanceReport
)
from app.services.alert_service import AlertService, ReportService
from app.core.security import require_admin, require_admin_or_dispatcher, require_any_role, get_current_user

# ─── Alerts Router ────────────────────────────────────────────────────────────
alerts_router = APIRouter(prefix="/alerts", tags=["Alerts & Monitoring"])


@alerts_router.get("", response_model=AlertListResponse, summary="List all alerts")
def list_alerts(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=200),
    unresolved_only: bool = Query(False),
    severity: Optional[AlertSeverity] = None,
    db: Session = Depends(get_db),
    _=Depends(require_admin_or_dispatcher),
):
    alerts, total = AlertService.get_all(db, skip, limit, unresolved_only, severity)
    return AlertListResponse(total=total, alerts=alerts)


@alerts_router.post("", response_model=AlertResponse, status_code=status.HTTP_201_CREATED,
                    summary="Report an alert")
def create_alert(
    data: AlertCreate,
    db: Session = Depends(get_db),
    current_user=Depends(require_any_role),
):
    return AlertService.create(db, data, reported_by=current_user.id)


@alerts_router.patch("/{alert_id}/resolve", response_model=AlertResponse,
                     summary="Resolve an alert (Admin/Dispatcher)")
def resolve_alert(
    alert_id: int,
    data: AlertResolve,
    db: Session = Depends(get_db),
    _=Depends(require_admin_or_dispatcher),
):
    return AlertService.resolve(db, alert_id, data)


@alerts_router.post("/auto-scan", summary="Auto-scan fleet and generate alerts (Admin)")
def auto_scan(
    db: Session = Depends(get_db),
    _=Depends(require_admin),
):
    generated = AlertService.auto_generate_alerts(db)
    return {"message": f"Auto-scan complete. {len(generated)} new alerts generated."}


# ─── Reports Router ───────────────────────────────────────────────────────────
reports_router = APIRouter(prefix="/reports", tags=["Operations & Reports"])


@reports_router.get("/fleet-summary", response_model=FleetSummaryReport,
                    summary="Real-time fleet summary dashboard")
def fleet_summary(
    db: Session = Depends(get_db),
    _=Depends(require_admin_or_dispatcher),
):
    return ReportService.fleet_summary(db)


@reports_router.get("/daily-performance", response_model=TripPerformanceReport,
                    summary="Daily trip performance report")
def daily_performance(
    report_date: Optional[date] = Query(None, description="Date in YYYY-MM-DD format (defaults to today)"),
    db: Session = Depends(get_db),
    _=Depends(require_admin_or_dispatcher),
):
    return ReportService.daily_trip_performance(db, report_date)
