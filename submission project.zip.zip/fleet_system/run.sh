#!/usr/bin/env bash
# run.sh — Quick start script for local development
set -e

echo "🚚 Smart Fleet Management System"
echo "================================="

# Check Python version
python_version=$(python3 --version 2>&1)
echo "✅ $python_version"

# Create virtualenv if not exists
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
fi

# Activate
source venv/bin/activate
echo "✅ Virtual environment activated"

# Install dependencies
echo "📥 Installing dependencies..."
pip install -r requirements.txt -q

# Create .env from example if not exists
if [ ! -f ".env" ]; then
    cp .env.example .env
    echo "⚙️  Created .env from .env.example — please review database settings"
fi

# Seed database
echo "🌱 Seeding database with demo data..."
python -m scripts.seed_db

# Start server
echo ""
echo "🚀 Starting server on http://localhost:8000"
echo "📖 API Docs: http://localhost:8000/api/docs"
echo "🔑 Admin login: admin@fleet.com / Admin@1234"
echo ""
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
