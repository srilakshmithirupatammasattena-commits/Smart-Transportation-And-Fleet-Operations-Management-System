from fastapi import APIRouter, Depends, Query, status, HTTPException
from sqlalchemy.orm import Session
from typing import Optional

from app.db.database import get_db
from app.models.user import User, UserRole
from app.schemas.user import UserResponse, UserUpdate, UserListResponse
from app.core.security import require_admin, get_current_user

router = APIRouter(prefix="/users", tags=["User Management"])


@router.get("", response_model=UserListResponse, summary="List all users (Admin only)")
def list_users(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=200),
    role: Optional[UserRole] = None,
    db: Session = Depends(get_db),
    _=Depends(require_admin),
):
    query = db.query(User)
    if role:
        query = query.filter(User.role == role)
    total = query.count()
    users = query.offset(skip).limit(limit).all()
    return UserListResponse(total=total, users=users)


@router.get("/drivers", response_model=UserListResponse, summary="List all drivers")
def list_drivers(
    db: Session = Depends(get_db),
    _=Depends(require_admin),
):
    drivers = db.query(User).filter(User.role == UserRole.driver, User.is_active == True).all()
    return UserListResponse(total=len(drivers), users=drivers)


@router.get("/{user_id}", response_model=UserResponse, summary="Get user by ID")
def get_user(
    user_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    # Drivers can only see their own profile
    if current_user.role == UserRole.driver and current_user.id != user_id:
        raise HTTPException(status_code=403, detail="Drivers can only view their own profile")
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user


@router.put("/{user_id}", response_model=UserResponse, summary="Update user (Admin only)")
def update_user(
    user_id: int,
    data: UserUpdate,
    db: Session = Depends(get_db),
    _=Depends(require_admin),
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    for field, value in data.model_dump(exclude_unset=True).items():
        setattr(user, field, value)
    db.commit()
    db.refresh(user)
    return user


@router.delete("/{user_id}", summary="Deactivate user (Admin only)")
def deactivate_user(
    user_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(require_admin),
):
    if current_user.id == user_id:
        raise HTTPException(status_code=400, detail="Cannot deactivate your own account")
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.is_active = False
    db.commit()
    return {"message": f"User '{user.email}' deactivated"}
