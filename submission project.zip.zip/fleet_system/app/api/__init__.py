from fastapi import APIRouter

from app.api.endpoints.auth import router as auth_router
from app.api.endpoints.users import router as users_router
from app.api.endpoints.vehicles import router as vehicles_router
from app.api.endpoints.routes import router as routes_router
from app.api.endpoints.trips import router as trips_router
from app.api.endpoints.alerts import alerts_router, reports_router

api_router = APIRouter()

api_router.include_router(auth_router)
api_router.include_router(users_router)
api_router.include_router(vehicles_router)
api_router.include_router(routes_router)
api_router.include_router(trips_router)
api_router.include_router(alerts_router)
api_router.include_router(reports_router)
