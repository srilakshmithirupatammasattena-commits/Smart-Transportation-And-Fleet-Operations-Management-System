from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.schemas.route import RouteCreate, RouteUpdate, RouteResponse, RouteListResponse
from app.services.route_service import RouteService
from app.core.security import require_admin, require_any_role

router = APIRouter(prefix="/routes", tags=["Route Management"])


@router.get("", response_model=RouteListResponse, summary="List all routes")
def list_routes(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=200),
    active_only: bool = Query(True),
    db: Session = Depends(get_db),
    _=Depends(require_any_role),
):
    routes, total = RouteService.get_all(db, skip, limit, active_only)
    return RouteListResponse(total=total, routes=routes)


@router.post("", response_model=RouteResponse, status_code=status.HTTP_201_CREATED,
             summary="Create a new route (Admin only)")
def create_route(
    data: RouteCreate,
    db: Session = Depends(get_db),
    _=Depends(require_admin),
):
    return RouteService.create(db, data)


@router.get("/{route_id}", response_model=RouteResponse, summary="Get route by ID")
def get_route(
    route_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_any_role),
):
    return RouteService.get_by_id(db, route_id)


@router.put("/{route_id}", response_model=RouteResponse, summary="Update route (Admin only)")
def update_route(
    route_id: int,
    data: RouteUpdate,
    db: Session = Depends(get_db),
    _=Depends(require_admin),
):
    return RouteService.update(db, route_id, data)


@router.delete("/{route_id}", summary="Delete route (Admin only)")
def delete_route(
    route_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_admin),
):
    return RouteService.delete(db, route_id)
