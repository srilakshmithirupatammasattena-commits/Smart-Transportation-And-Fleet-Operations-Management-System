from sqlalchemy.orm import Session
from fastapi import HTTPException, status
from loguru import logger
from datetime import timedelta

from app.models.user import User
from app.schemas.user import UserCreate, LoginRequest, TokenResponse
from app.core.security import hash_password, verify_password, create_access_token, create_refresh_token, decode_token
from app.core.config import settings


class AuthService:

    @staticmethod
    def register_user(db: Session, data: UserCreate, created_by_role: str = "admin") -> User:
        """Create a new user. Only admins can create admin/dispatcher accounts."""
        existing = db.query(User).filter(User.email == data.email).first()
        if existing:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                                detail=f"Email '{data.email}' is already registered")

        user = User(
            full_name=data.full_name,
            email=data.email,
            hashed_password=hash_password(data.password),
            role=data.role,
            phone=data.phone,
        )
        db.add(user)
        db.commit()
        db.refresh(user)
        logger.info(f"New user registered: {user.email} role={user.role}")
        return user

    @staticmethod
    def authenticate(db: Session, data: LoginRequest) -> TokenResponse:
        """Verify credentials and return JWT tokens."""
        user = db.query(User).filter(User.email == data.email).first()
        if not user or not verify_password(data.password, user.hashed_password):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid email or password",
            )
        if not user.is_active:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Account is disabled")

        access_token = create_access_token(subject=user.id, role=user.role)
        refresh_token = create_refresh_token(subject=user.id)
        expire_seconds = settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60

        logger.info(f"User logged in: {user.email}")
        return TokenResponse(
            access_token=access_token,
            refresh_token=refresh_token,
            expires_in=expire_seconds,
            user=user,
        )

    @staticmethod
    def refresh_access_token(db: Session, refresh_token: str) -> dict:
        """Issue a new access token using a valid refresh token."""
        payload = decode_token(refresh_token)
        if payload.get("type") != "refresh":
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid token type")

        user = db.query(User).filter(User.id == int(payload["sub"]), User.is_active == True).first()
        if not user:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found")

        new_access = create_access_token(subject=user.id, role=user.role)
        return {
            "access_token": new_access,
            "token_type": "bearer",
            "expires_in": settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        }
