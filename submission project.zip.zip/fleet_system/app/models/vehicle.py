from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, Enum as SAEnum, Text
from sqlalchemy.orm import relationship
import enum

from app.db.database import Base


class VehicleType(str, enum.Enum):
    truck = "truck"
    bus = "bus"
    van = "van"
    car = "car"


class FuelStatus(str, enum.Enum):
    full = "full"
    adequate = "adequate"
    low = "low"
    critical = "critical"


class MaintenanceStatus(str, enum.Enum):
    good = "good"
    due_soon = "due_soon"
    overdue = "overdue"
    in_maintenance = "in_maintenance"


class Vehicle(Base):
    __tablename__ = "vehicles"

    id = Column(Integer, primary_key=True, index=True)
    vehicle_id = Column(String(50), unique=True, index=True, nullable=False)  # e.g. "TRK-001"
    registration_number = Column(String(50), unique=True, nullable=False)
    vehicle_type = Column(SAEnum(VehicleType), nullable=False)
    make = Column(String(80), nullable=True)
    model = Column(String(80), nullable=True)
    year = Column(Integer, nullable=True)
    capacity = Column(Integer, nullable=False)           # Passengers or tonnes
    fuel_level = Column(Float, default=100.0)           # Percentage 0–100
    fuel_status = Column(SAEnum(FuelStatus), default=FuelStatus.full)
    mileage = Column(Float, default=0.0)                # Total km
    last_maintenance_date = Column(DateTime(timezone=True), nullable=True)
    next_maintenance_due = Column(DateTime(timezone=True), nullable=True)
    maintenance_status = Column(SAEnum(MaintenanceStatus), default=MaintenanceStatus.good)
    is_available = Column(Boolean, default=True)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc),
                        onupdate=lambda: datetime.now(timezone.utc))

    # Relationships
    trips = relationship("Trip", back_populates="vehicle")
    alerts = relationship("Alert", back_populates="vehicle")

    def __repr__(self):
        return f"<Vehicle {self.vehicle_id} type={self.vehicle_type}>"
