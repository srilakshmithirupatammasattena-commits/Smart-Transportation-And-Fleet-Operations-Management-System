from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional


class RouteBase(BaseModel):
    route_code: str = Field(..., min_length=3, max_length=50, examples=["RT-HYD-MUM"])
    name: str = Field(..., min_length=3, max_length=200)
    origin: str = Field(..., min_length=2, max_length=200)
    destination: str = Field(..., min_length=2, max_length=200)
    waypoints: Optional[str] = None   # JSON string e.g. '["Pune", "Nashik"]'
    distance_km: float = Field(..., gt=0)
    estimated_duration_hours: float = Field(..., gt=0)
    description: Optional[str] = None


class RouteCreate(RouteBase):
    pass


class RouteUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=3, max_length=200)
    waypoints: Optional[str] = None
    distance_km: Optional[float] = Field(None, gt=0)
    estimated_duration_hours: Optional[float] = Field(None, gt=0)
    is_active: Optional[bool] = None
    description: Optional[str] = None


class RouteResponse(RouteBase):
    id: int
    is_active: bool
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class RouteListResponse(BaseModel):
    total: int
    routes: list[RouteResponse]
