from sqlalchemy import create_engine, event
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from loguru import logger

from app.core.config import settings

# ─── Engine ──────────────────────────────────────────────────────────────────
connect_args = {}
if "sqlite" in settings.DATABASE_URL:
    connect_args["check_same_thread"] = False  # SQLite-only setting

engine = create_engine(
    settings.DATABASE_URL,
    connect_args=connect_args,
    pool_pre_ping=True,          # Detect stale connections
    pool_size=10,                # Connection pool size
    max_overflow=20,             # Max overflow connections
    echo=settings.DEBUG,         # Log SQL queries in debug mode
)

# ─── Session factory ─────────────────────────────────────────────────────────
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# ─── Base class for all ORM models ───────────────────────────────────────────
Base = declarative_base()


# ─── FastAPI dependency ───────────────────────────────────────────────────────
def get_db():
    """Yield a DB session and ensure it is closed after the request."""
    db = SessionLocal()
    try:
        yield db
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def init_db():
    """Create all tables in the database (used at startup)."""
    # Import all models so SQLAlchemy knows about them before creating tables
    from app.models import user, vehicle, route, trip, alert  # noqa: F401
    Base.metadata.create_all(bind=engine)
    logger.info("Database tables created / verified.")
