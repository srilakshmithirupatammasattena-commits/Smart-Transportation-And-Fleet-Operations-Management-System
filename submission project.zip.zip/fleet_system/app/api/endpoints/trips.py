from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session
from typing import Optional

from app.db.database import get_db
from app.models.trip import TripStatus
from app.models.user import UserRole
from app.schemas.trip import (
    TripCreate, TripUpdate, TripStatusUpdate,
    TripResponse, TripDetailResponse, TripListResponse, TripLogResponse
)
from app.services.trip_service import TripService
from app.core.security import require_admin_or_dispatcher, require_any_role, get_current_user

router = APIRouter(prefix="/trips", tags=["Trip Management"])


@router.get("", response_model=TripListResponse, summary="List trips")
def list_trips(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=200),
    trip_status: Optional[TripStatus] = Query(None, alias="status"),
    driver_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    # Drivers can only see their own trips
    if current_user.role == UserRole.driver:
        driver_id = current_user.id
    trips, total = TripService.get_all(db, skip, limit, trip_status, driver_id)
    return TripListResponse(total=total, trips=trips)


@router.post("", response_model=TripResponse, status_code=status.HTTP_201_CREATED,
             summary="Create a new trip (Admin/Dispatcher)")
def create_trip(
    data: TripCreate,
    db: Session = Depends(get_db),
    current_user=Depends(require_admin_or_dispatcher),
):
    return TripService.create(db, data, actor_id=current_user.id)


@router.get("/my-trips", response_model=TripListResponse, summary="Driver: view my trips")
def my_trips(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    trips = TripService.get_driver_trips(db, current_user.id)
    return TripListResponse(total=len(trips), trips=trips)


@router.get("/{trip_id}", response_model=TripDetailResponse, summary="Get trip details with logs")
def get_trip(
    trip_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    trip = TripService.get_by_id(db, trip_id)
    # Drivers can only view their own trips
    if current_user.role == UserRole.driver and trip.driver_id != current_user.id:
        from fastapi import HTTPException
        raise HTTPException(status_code=403, detail="Access denied")
    logs = TripService.get_trip_history(db, trip_id)
    trip.logs = logs
    return trip


@router.put("/{trip_id}", response_model=TripResponse, summary="Update trip details (Admin/Dispatcher)")
def update_trip(
    trip_id: int,
    data: TripUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(require_admin_or_dispatcher),
):
    return TripService.update(db, trip_id, data, actor_id=current_user.id)


@router.patch("/{trip_id}/status", response_model=TripResponse,
              summary="Update trip status (all roles, context-aware)")
def update_trip_status(
    trip_id: int,
    data: TripStatusUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """
    - Drivers can only update status of their own trips.
    - Dispatchers and Admins can update any trip.
    """
    if current_user.role == UserRole.driver:
        trip = TripService.get_by_id(db, trip_id)
        if trip.driver_id != current_user.id:
            from fastapi import HTTPException
            raise HTTPException(status_code=403, detail="Drivers can only update their own trip status")
    return TripService.update_status(db, trip_id, data, actor_id=current_user.id)


@router.get("/{trip_id}/logs", response_model=list[TripLogResponse],
            summary="Get trip audit logs")
def get_trip_logs(
    trip_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_admin_or_dispatcher),
):
    return TripService.get_trip_history(db, trip_id)
