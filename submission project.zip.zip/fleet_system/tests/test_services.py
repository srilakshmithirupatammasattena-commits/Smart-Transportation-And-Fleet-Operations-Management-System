"""
Unit tests for core services: security, vehicle logic, trip state machine.
These tests are isolated and don't need a running server.
"""
import pytest
from datetime import datetime, timezone, timedelta
from unittest.mock import MagicMock, patch

from app.core.security import hash_password, verify_password, create_access_token, decode_token
from app.services.vehicle_service import _compute_fuel_status, _compute_maintenance_status
from app.models.vehicle import FuelStatus, MaintenanceStatus


# ─── Security unit tests ──────────────────────────────────────────────────────

class TestPasswordHashing:
    def test_hash_is_not_plain_text(self):
        h = hash_password("MyPassword@1")
        assert h != "MyPassword@1"
        assert h.startswith("$2b$")

    def test_verify_correct_password(self):
        h = hash_password("Correct@1")
        assert verify_password("Correct@1", h) is True

    def test_verify_wrong_password(self):
        h = hash_password("Correct@1")
        assert verify_password("Wrong@1", h) is False

    def test_same_password_different_hashes(self):
        """bcrypt uses random salts — same password yields different hashes."""
        h1 = hash_password("SamePass@1")
        h2 = hash_password("SamePass@1")
        assert h1 != h2
        assert verify_password("SamePass@1", h1)
        assert verify_password("SamePass@1", h2)


class TestJWTTokens:
    def test_create_and_decode_access_token(self):
        token = create_access_token(subject=42, role="admin")
        payload = decode_token(token)
        assert payload["sub"] == "42"
        assert payload["role"] == "admin"
        assert payload["type"] == "access"

    def test_expired_token_rejected(self):
        from fastapi import HTTPException
        token = create_access_token(subject=1, role="driver",
                                    expires_delta=timedelta(seconds=-1))
        with pytest.raises(HTTPException) as exc:
            decode_token(token)
        assert exc.value.status_code == 401

    def test_tampered_token_rejected(self):
        from fastapi import HTTPException
        token = create_access_token(subject=1, role="admin")
        bad_token = token[:-5] + "XXXXX"
        with pytest.raises(HTTPException):
            decode_token(bad_token)

    def test_dispatcher_role_in_token(self):
        token = create_access_token(subject=7, role="dispatcher")
        payload = decode_token(token)
        assert payload["role"] == "dispatcher"


# ─── Vehicle logic unit tests ─────────────────────────────────────────────────

class TestFuelStatusComputation:
    def test_full(self):
        assert _compute_fuel_status(100.0) == FuelStatus.full
        assert _compute_fuel_status(75.0) == FuelStatus.full

    def test_adequate(self):
        assert _compute_fuel_status(74.9) == FuelStatus.adequate
        assert _compute_fuel_status(40.0) == FuelStatus.adequate

    def test_low(self):
        assert _compute_fuel_status(39.9) == FuelStatus.low
        assert _compute_fuel_status(15.0) == FuelStatus.low

    def test_critical(self):
        assert _compute_fuel_status(14.9) == FuelStatus.critical
        assert _compute_fuel_status(0.0) == FuelStatus.critical


class TestMaintenanceStatusComputation:
    def test_none_is_good(self):
        assert _compute_maintenance_status(None) == MaintenanceStatus.good

    def test_future_far_is_good(self):
        future = datetime.now(timezone.utc) + timedelta(days=60)
        assert _compute_maintenance_status(future) == MaintenanceStatus.good

    def test_due_soon_within_14_days(self):
        soon = datetime.now(timezone.utc) + timedelta(days=7)
        assert _compute_maintenance_status(soon) == MaintenanceStatus.due_soon

    def test_overdue_in_past(self):
        past = datetime.now(timezone.utc) - timedelta(days=3)
        assert _compute_maintenance_status(past) == MaintenanceStatus.overdue


# ─── Trip state machine unit tests ───────────────────────────────────────────

class TestTripStateMachine:
    def test_valid_transitions(self):
        from app.services.trip_service import VALID_TRANSITIONS
        from app.models.trip import TripStatus

        # scheduled can go to in_progress or cancelled
        assert TripStatus.in_progress in VALID_TRANSITIONS[TripStatus.scheduled]
        assert TripStatus.cancelled in VALID_TRANSITIONS[TripStatus.scheduled]

        # in_progress can go to completed, delayed, cancelled
        assert TripStatus.completed in VALID_TRANSITIONS[TripStatus.in_progress]
        assert TripStatus.delayed in VALID_TRANSITIONS[TripStatus.in_progress]
        assert TripStatus.cancelled in VALID_TRANSITIONS[TripStatus.in_progress]

        # delayed can recover
        assert TripStatus.in_progress in VALID_TRANSITIONS[TripStatus.delayed]

        # terminal states have no outgoing transitions
        assert VALID_TRANSITIONS[TripStatus.completed] == []
        assert VALID_TRANSITIONS[TripStatus.cancelled] == []

    def test_cannot_go_backwards(self):
        from app.services.trip_service import VALID_TRANSITIONS
        from app.models.trip import TripStatus

        assert TripStatus.scheduled not in VALID_TRANSITIONS[TripStatus.in_progress]
        assert TripStatus.scheduled not in VALID_TRANSITIONS[TripStatus.completed]


# ─── Schema validation unit tests ────────────────────────────────────────────

class TestUserSchema:
    def test_password_must_have_digit(self):
        from pydantic import ValidationError
        from app.schemas.user import UserCreate

        with pytest.raises(ValidationError) as exc:
            UserCreate(full_name="Test User", email="t@t.com",
                       password="NoDigitPass!", role="driver")
        assert "digit" in str(exc.value).lower()

    def test_password_must_have_uppercase(self):
        from pydantic import ValidationError
        from app.schemas.user import UserCreate

        with pytest.raises(ValidationError) as exc:
            UserCreate(full_name="Test User", email="t@t.com",
                       password="alllowercase1", role="driver")
        assert "uppercase" in str(exc.value).lower()

    def test_valid_user_create(self):
        from app.schemas.user import UserCreate

        u = UserCreate(full_name="Valid User", email="valid@test.com",
                       password="ValidPass1", role="driver")
        assert u.email == "valid@test.com"


class TestTripSchema:
    def test_departure_must_be_before_arrival(self):
        from pydantic import ValidationError
        from app.schemas.trip import TripCreate
        now = datetime.now(timezone.utc)

        with pytest.raises(ValidationError) as exc:
            TripCreate(
                vehicle_id=1, driver_id=1, route_id=1,
                scheduled_departure=now + timedelta(hours=5),
                scheduled_arrival=now + timedelta(hours=2),  # BEFORE departure
            )
        assert "departure" in str(exc.value).lower() or "arrival" in str(exc.value).lower()

    def test_valid_trip_create(self):
        from app.schemas.trip import TripCreate
        now = datetime.now(timezone.utc)

        t = TripCreate(
            vehicle_id=1, driver_id=2, route_id=1,
            scheduled_departure=now + timedelta(hours=1),
            scheduled_arrival=now + timedelta(hours=8),
        )
        assert t.vehicle_id == 1


class TestVehicleSchema:
    def test_fuel_level_bounds(self):
        from pydantic import ValidationError
        from app.schemas.vehicle import VehicleCreate

        with pytest.raises(ValidationError):
            VehicleCreate(vehicle_id="X1", registration_number="R1",
                          vehicle_type="truck", capacity=10, fuel_level=110.0)  # >100

        with pytest.raises(ValidationError):
            VehicleCreate(vehicle_id="X2", registration_number="R2",
                          vehicle_type="truck", capacity=10, fuel_level=-5.0)  # <0

    def test_capacity_must_be_positive(self):
        from pydantic import ValidationError
        from app.schemas.vehicle import VehicleCreate

        with pytest.raises(ValidationError):
            VehicleCreate(vehicle_id="X3", registration_number="R3",
                          vehicle_type="truck", capacity=0)
