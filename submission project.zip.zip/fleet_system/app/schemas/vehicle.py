from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional
from app.models.vehicle import VehicleType, FuelStatus, MaintenanceStatus


class VehicleBase(BaseModel):
    vehicle_id: str = Field(..., min_length=3, max_length=50, examples=["TRK-001"])
    registration_number: str = Field(..., min_length=3, max_length=50)
    vehicle_type: VehicleType
    make: Optional[str] = Field(None, max_length=80)
    model: Optional[str] = Field(None, max_length=80)
    year: Optional[int] = Field(None, ge=1990, le=2030)
    capacity: int = Field(..., ge=1)
    notes: Optional[str] = None


class VehicleCreate(VehicleBase):
    fuel_level: float = Field(100.0, ge=0.0, le=100.0)
    mileage: float = Field(0.0, ge=0.0)
    last_maintenance_date: Optional[datetime] = None
    next_maintenance_due: Optional[datetime] = None


class VehicleUpdate(BaseModel):
    vehicle_type: Optional[VehicleType] = None
    capacity: Optional[int] = Field(None, ge=1)
    fuel_level: Optional[float] = Field(None, ge=0.0, le=100.0)
    fuel_status: Optional[FuelStatus] = None
    mileage: Optional[float] = Field(None, ge=0.0)
    last_maintenance_date: Optional[datetime] = None
    next_maintenance_due: Optional[datetime] = None
    maintenance_status: Optional[MaintenanceStatus] = None
    is_available: Optional[bool] = None
    notes: Optional[str] = None


class VehicleResponse(VehicleBase):
    id: int
    fuel_level: float
    fuel_status: FuelStatus
    mileage: float
    maintenance_status: MaintenanceStatus
    is_available: bool
    last_maintenance_date: Optional[datetime]
    next_maintenance_due: Optional[datetime]
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class VehicleListResponse(BaseModel):
    total: int
    vehicles: list[VehicleResponse]


class FuelUpdateRequest(BaseModel):
    fuel_level: float = Field(..., ge=0.0, le=100.0)
    liters_added: Optional[float] = Field(None, ge=0.0)
    cost: Optional[float] = Field(None, ge=0.0)
    note: Optional[str] = None
