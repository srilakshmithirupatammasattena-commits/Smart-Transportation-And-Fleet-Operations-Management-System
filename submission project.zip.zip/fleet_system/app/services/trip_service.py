from datetime import datetime, timezone
from typing import Optional
from sqlalchemy.orm import Session
from fastapi import HTTPException, status
from loguru import logger

from app.models.trip import Trip, TripLog, TripStatus
from app.models.vehicle import Vehicle
from app.models.user import User, UserRole
from app.schemas.trip import TripCreate, TripUpdate, TripStatusUpdate


# Valid status transitions (state machine)
VALID_TRANSITIONS: dict[TripStatus, list[TripStatus]] = {
    TripStatus.scheduled:    [TripStatus.in_progress, TripStatus.cancelled],
    TripStatus.in_progress:  [TripStatus.completed, TripStatus.delayed, TripStatus.cancelled],
    TripStatus.delayed:      [TripStatus.in_progress, TripStatus.completed, TripStatus.cancelled],
    TripStatus.completed:    [],   # terminal
    TripStatus.cancelled:    [],   # terminal
}


def _generate_trip_code(db: Session) -> str:
    today = datetime.now(timezone.utc).strftime("%Y%m%d")
    count = db.query(Trip).filter(Trip.trip_code.like(f"TRIP-{today}-%")).count()
    return f"TRIP-{today}-{count + 1:04d}"


def _add_log(db: Session, trip_id: int, actor_id: Optional[int], event: str, detail: str = None):
    log = TripLog(trip_id=trip_id, actor_id=actor_id, event=event, detail=detail)
    db.add(log)


class TripService:

    @staticmethod
    def create(db: Session, data: TripCreate, actor_id: int) -> Trip:
        # Validate vehicle exists and is available
        vehicle = db.query(Vehicle).filter(Vehicle.id == data.vehicle_id).first()
        if not vehicle:
            raise HTTPException(status_code=404, detail="Vehicle not found")
        if not vehicle.is_available:
            raise HTTPException(status_code=409, detail=f"Vehicle '{vehicle.vehicle_id}' is not available")

        # Validate driver exists and has driver role
        driver = db.query(User).filter(User.id == data.driver_id).first()
        if not driver:
            raise HTTPException(status_code=404, detail="Driver not found")
        if driver.role != UserRole.driver:
            raise HTTPException(status_code=400, detail="Assigned user is not a driver")

        # Check driver not already on an active trip
        active_driver_trip = db.query(Trip).filter(
            Trip.driver_id == data.driver_id,
            Trip.status.in_([TripStatus.scheduled, TripStatus.in_progress])
        ).first()
        if active_driver_trip:
            raise HTTPException(status_code=409,
                                detail=f"Driver already assigned to trip {active_driver_trip.trip_code}")

        # Validate route
        from app.models.route import Route
        route = db.query(Route).filter(Route.id == data.route_id, Route.is_active == True).first()
        if not route:
            raise HTTPException(status_code=404, detail="Route not found or inactive")

        trip = Trip(
            trip_code=_generate_trip_code(db),
            dispatcher_id=actor_id,
            **data.model_dump(),
        )
        db.add(trip)

        # Mark vehicle unavailable
        vehicle.is_available = False
        db.flush()

        _add_log(db, trip.id, actor_id, "TRIP_CREATED",
                 f"Trip {trip.trip_code} created. Vehicle: {vehicle.vehicle_id}, Driver: {driver.full_name}")
        db.commit()
        db.refresh(trip)
        logger.info(f"Trip created: {trip.trip_code}")
        return trip

    @staticmethod
    def get_all(db: Session, skip: int = 0, limit: int = 50,
                status_filter: Optional[TripStatus] = None,
                driver_id: Optional[int] = None) -> tuple[list[Trip], int]:
        query = db.query(Trip).filter(Trip.is_active == True)
        if status_filter:
            query = query.filter(Trip.status == status_filter)
        if driver_id:
            query = query.filter(Trip.driver_id == driver_id)
        total = query.count()
        return query.order_by(Trip.scheduled_departure.desc()).offset(skip).limit(limit).all(), total

    @staticmethod
    def get_by_id(db: Session, trip_id: int) -> Trip:
        t = db.query(Trip).filter(Trip.id == trip_id, Trip.is_active == True).first()
        if not t:
            raise HTTPException(status_code=404, detail=f"Trip {trip_id} not found")
        return t

    @staticmethod
    def update(db: Session, trip_id: int, data: TripUpdate, actor_id: int) -> Trip:
        t = TripService.get_by_id(db, trip_id)
        if t.status not in [TripStatus.scheduled]:
            raise HTTPException(status_code=400,
                                detail="Only scheduled trips can be edited. Use status update for in-progress trips.")
        for field, value in data.model_dump(exclude_unset=True).items():
            setattr(t, field, value)
        t.updated_at = datetime.now(timezone.utc)
        _add_log(db, trip_id, actor_id, "TRIP_UPDATED", str(data.model_dump(exclude_unset=True)))
        db.commit()
        db.refresh(t)
        return t

    @staticmethod
    def update_status(db: Session, trip_id: int, data: TripStatusUpdate, actor_id: int) -> Trip:
        t = TripService.get_by_id(db, trip_id)

        # Enforce state machine
        allowed = VALID_TRANSITIONS.get(t.status, [])
        if data.status not in allowed:
            raise HTTPException(
                status_code=400,
                detail=f"Cannot transition from '{t.status}' to '{data.status}'. Allowed: {[s.value for s in allowed]}"
            )

        old_status = t.status
        t.status = data.status

        now = datetime.now(timezone.utc)

        if data.status == TripStatus.in_progress and not t.actual_departure:
            t.actual_departure = now
        elif data.status == TripStatus.completed:
            t.actual_arrival = now
            if data.fuel_used_liters is not None:
                t.fuel_used_liters = data.fuel_used_liters
            if data.distance_covered_km is not None:
                t.distance_covered_km = data.distance_covered_km
            # Free the vehicle
            vehicle = db.query(Vehicle).filter(Vehicle.id == t.vehicle_id).first()
            if vehicle:
                vehicle.is_available = True
                if data.distance_covered_km:
                    vehicle.mileage += data.distance_covered_km
        elif data.status == TripStatus.cancelled:
            vehicle = db.query(Vehicle).filter(Vehicle.id == t.vehicle_id).first()
            if vehicle:
                vehicle.is_available = True

        if data.delay_minutes is not None:
            t.delay_minutes = data.delay_minutes
        if data.delay_reason:
            t.delay_reason = data.delay_reason

        t.updated_at = now
        detail = (f"Status: {old_status} → {data.status}. "
                  f"Delay: {data.delay_minutes or 0}min. Note: {data.note or ''}")
        _add_log(db, trip_id, actor_id, "STATUS_CHANGED", detail)
        db.commit()
        db.refresh(t)
        logger.info(f"Trip {t.trip_code} status → {data.status}")
        return t

    @staticmethod
    def get_trip_history(db: Session, trip_id: int) -> list[TripLog]:
        TripService.get_by_id(db, trip_id)
        return db.query(TripLog).filter(TripLog.trip_id == trip_id).order_by(TripLog.created_at).all()

    @staticmethod
    def get_driver_trips(db: Session, driver_id: int) -> list[Trip]:
        return db.query(Trip).filter(
            Trip.driver_id == driver_id, Trip.is_active == True
        ).order_by(Trip.scheduled_departure.desc()).all()
