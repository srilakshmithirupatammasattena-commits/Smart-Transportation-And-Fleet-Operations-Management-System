from fastapi import FastAPI, Request, status
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from loguru import logger
import time
import sys

from app.core.config import settings
from app.api import api_router
from app.db.database import init_db

# ─── Logging setup ────────────────────────────────────────────────────────────
logger.remove()
logger.add(
    sys.stdout,
    format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level}</level> | {message}",
    level="DEBUG" if settings.DEBUG else "INFO",
)
logger.add("logs/fleet_system.log", rotation="10 MB", retention="30 days", level="INFO")

# ─── App factory ─────────────────────────────────────────────────────────────
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="""
## 🚚 Smart Transportation & Fleet Operations Management System

A scalable backend API for managing:
- **Fleet vehicles** (CRUD, fuel tracking, maintenance scheduling)
- **Routes** (origin → destination with waypoints)
- **Trips** (full lifecycle: Scheduled → In-Progress → Completed/Delayed)
- **Users** with RBAC (**Admin** / **Dispatcher** / **Driver**)
- **Alerts** (fuel-low, breakdown, maintenance-due)
- **Operations Reports** (daily performance, fleet summary)

### Authentication
All endpoints (except `/api/auth/login`) require a Bearer JWT token.
Use `/api/auth/login` to obtain tokens, then click **Authorize** above.
""",
    openapi_url=f"{settings.API_PREFIX}/openapi.json",
    docs_url=f"{settings.API_PREFIX}/docs",
    redoc_url=f"{settings.API_PREFIX}/redoc",
)

# ─── Middleware ───────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.BACKEND_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(TrustedHostMiddleware, allowed_hosts=["*"])  # Restrict in production


@app.middleware("http")
async def log_requests(request: Request, call_next):
    start = time.time()
    response = await call_next(request)
    duration = (time.time() - start) * 1000
    logger.info(f"{request.method} {request.url.path} → {response.status_code} ({duration:.1f}ms)")
    return response


# ─── Global exception handlers ────────────────────────────────────────────────
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.exception(f"Unhandled error on {request.method} {request.url.path}: {exc}")
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": "An internal server error occurred. Please try again later."},
    )


# ─── Startup / Shutdown ───────────────────────────────────────────────────────
@app.on_event("startup")
async def startup_event():
    logger.info(f"Starting {settings.APP_NAME} v{settings.APP_VERSION}")
    init_db()
    logger.info(f"API docs available at {settings.API_PREFIX}/docs")


@app.on_event("shutdown")
async def shutdown_event():
    logger.info("Application shutting down...")


# ─── Routes ───────────────────────────────────────────────────────────────────
app.include_router(api_router, prefix=settings.API_PREFIX)


@app.get("/", tags=["Health"])
def root():
    return {
        "service": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "status": "running",
        "docs": f"{settings.API_PREFIX}/docs",
    }


@app.get("/health", tags=["Health"])
def health_check():
    """Health check endpoint for load balancers and deployment platforms."""
    return {"status": "healthy", "version": settings.APP_VERSION}
