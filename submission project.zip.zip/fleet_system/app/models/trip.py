from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Enum as SAEnum, Text, Boolean
from sqlalchemy.orm import relationship
import enum

from app.db.database import Base


class TripStatus(str, enum.Enum):
    scheduled = "scheduled"
    in_progress = "in_progress"
    completed = "completed"
    delayed = "delayed"
    cancelled = "cancelled"


class Trip(Base):
    __tablename__ = "trips"

    id = Column(Integer, primary_key=True, index=True)
    trip_code = Column(String(50), unique=True, index=True, nullable=False)   # e.g. "TRIP-20240403-001"
    vehicle_id = Column(Integer, ForeignKey("vehicles.id"), nullable=False)
    driver_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    route_id = Column(Integer, ForeignKey("routes.id"), nullable=False)
    dispatcher_id = Column(Integer, ForeignKey("users.id"), nullable=True)

    status = Column(SAEnum(TripStatus), default=TripStatus.scheduled, nullable=False)
    scheduled_departure = Column(DateTime(timezone=True), nullable=False)
    scheduled_arrival = Column(DateTime(timezone=True), nullable=False)
    actual_departure = Column(DateTime(timezone=True), nullable=True)
    actual_arrival = Column(DateTime(timezone=True), nullable=True)

    cargo_description = Column(String(500), nullable=True)
    cargo_weight_kg = Column(Float, nullable=True)
    passengers = Column(Integer, nullable=True)

    fuel_used_liters = Column(Float, nullable=True)
    distance_covered_km = Column(Float, nullable=True)
    delay_minutes = Column(Integer, default=0)
    delay_reason = Column(Text, nullable=True)

    notes = Column(Text, nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc),
                        onupdate=lambda: datetime.now(timezone.utc))

    # Relationships
    vehicle = relationship("Vehicle", back_populates="trips")
    driver = relationship("User", back_populates="trips_as_driver", foreign_keys=[driver_id])
    route = relationship("Route", back_populates="trips")
    alerts = relationship("Alert", back_populates="trip")
    logs = relationship("TripLog", back_populates="trip", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Trip {self.trip_code} status={self.status}>"


class TripLog(Base):
    """Immutable audit log for every trip status change or notable event."""
    __tablename__ = "trip_logs"

    id = Column(Integer, primary_key=True, index=True)
    trip_id = Column(Integer, ForeignKey("trips.id"), nullable=False)
    actor_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    event = Column(String(100), nullable=False)    # e.g. "STATUS_CHANGED", "DELAY_REPORTED"
    detail = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    trip = relationship("Trip", back_populates="logs")
