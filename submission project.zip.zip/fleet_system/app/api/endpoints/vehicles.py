from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session
from typing import Optional

from app.db.database import get_db
from app.models.vehicle import VehicleType
from app.schemas.vehicle import (
    VehicleCreate, VehicleUpdate, VehicleResponse,
    VehicleListResponse, FuelUpdateRequest
)
from app.services.vehicle_service import VehicleService
from app.core.security import require_admin, require_admin_or_dispatcher, require_any_role

router = APIRouter(prefix="/vehicles", tags=["Vehicle Management"])


@router.get("", response_model=VehicleListResponse, summary="List all vehicles")
def list_vehicles(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=200),
    vehicle_type: Optional[VehicleType] = None,
    available_only: bool = Query(False),
    db: Session = Depends(get_db),
    _=Depends(require_any_role),
):
    vehicles, total = VehicleService.get_all(db, skip, limit, vehicle_type, available_only)
    return VehicleListResponse(total=total, vehicles=vehicles)


@router.post("", response_model=VehicleResponse, status_code=status.HTTP_201_CREATED,
             summary="Add a new vehicle (Admin only)")
def create_vehicle(
    data: VehicleCreate,
    db: Session = Depends(get_db),
    _=Depends(require_admin),
):
    return VehicleService.create(db, data)


@router.get("/maintenance-due", response_model=VehicleListResponse,
            summary="Get vehicles needing maintenance")
def vehicles_maintenance_due(
    db: Session = Depends(get_db),
    _=Depends(require_admin_or_dispatcher),
):
    vehicles = VehicleService.get_maintenance_due(db)
    return VehicleListResponse(total=len(vehicles), vehicles=vehicles)


@router.get("/{vehicle_id}", response_model=VehicleResponse, summary="Get vehicle by ID")
def get_vehicle(
    vehicle_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_any_role),
):
    return VehicleService.get_by_id(db, vehicle_id)


@router.put("/{vehicle_id}", response_model=VehicleResponse, summary="Update vehicle (Admin only)")
def update_vehicle(
    vehicle_id: int,
    data: VehicleUpdate,
    db: Session = Depends(get_db),
    _=Depends(require_admin),
):
    return VehicleService.update(db, vehicle_id, data)


@router.delete("/{vehicle_id}", summary="Delete vehicle (Admin only)")
def delete_vehicle(
    vehicle_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_admin),
):
    return VehicleService.delete(db, vehicle_id)


@router.patch("/{vehicle_id}/fuel", response_model=VehicleResponse,
              summary="Update vehicle fuel level (Admin/Dispatcher)")
def update_fuel(
    vehicle_id: int,
    data: FuelUpdateRequest,
    db: Session = Depends(get_db),
    _=Depends(require_admin_or_dispatcher),
):
    return VehicleService.update_fuel(db, vehicle_id, data)
