from pydantic import BaseModel, Field, model_validator
from datetime import datetime
from typing import Optional
from app.models.trip import TripStatus


class TripBase(BaseModel):
    vehicle_id: int
    driver_id: int
    route_id: int
    scheduled_departure: datetime
    scheduled_arrival: datetime
    cargo_description: Optional[str] = Field(None, max_length=500)
    cargo_weight_kg: Optional[float] = Field(None, ge=0)
    passengers: Optional[int] = Field(None, ge=0)
    notes: Optional[str] = None

    @model_validator(mode="after")
    def departure_before_arrival(self):
        if self.scheduled_departure >= self.scheduled_arrival:
            raise ValueError("scheduled_departure must be before scheduled_arrival")
        return self


class TripCreate(TripBase):
    dispatcher_id: Optional[int] = None


class TripUpdate(BaseModel):
    cargo_description: Optional[str] = Field(None, max_length=500)
    cargo_weight_kg: Optional[float] = Field(None, ge=0)
    passengers: Optional[int] = Field(None, ge=0)
    notes: Optional[str] = None
    scheduled_departure: Optional[datetime] = None
    scheduled_arrival: Optional[datetime] = None


class TripStatusUpdate(BaseModel):
    status: TripStatus
    delay_minutes: Optional[int] = Field(None, ge=0)
    delay_reason: Optional[str] = None
    fuel_used_liters: Optional[float] = Field(None, ge=0)
    distance_covered_km: Optional[float] = Field(None, ge=0)
    note: Optional[str] = None


class TripLogResponse(BaseModel):
    id: int
    event: str
    detail: Optional[str]
    created_at: datetime

    model_config = {"from_attributes": True}


class TripResponse(TripBase):
    id: int
    trip_code: str
    status: TripStatus
    dispatcher_id: Optional[int]
    actual_departure: Optional[datetime]
    actual_arrival: Optional[datetime]
    fuel_used_liters: Optional[float]
    distance_covered_km: Optional[float]
    delay_minutes: int
    delay_reason: Optional[str]
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class TripDetailResponse(TripResponse):
    logs: list[TripLogResponse] = []


class TripListResponse(BaseModel):
    total: int
    trips: list[TripResponse]
