"""
Seed the database with initial data for development/demo purposes.
Run: python -m scripts.seed_db
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from datetime import datetime, timezone, timedelta
from app.db.database import SessionLocal, init_db
from app.models.user import User, UserRole
from app.models.vehicle import Vehicle, VehicleType, FuelStatus, MaintenanceStatus
from app.models.route import Route
from app.models.trip import Trip, TripStatus
from app.core.security import hash_password
from loguru import logger


def seed():
    init_db()
    db = SessionLocal()

    try:
        # ── Users ─────────────────────────────────────────────────────────────
        if db.query(User).count() == 0:
            users = [
                User(full_name="System Admin", email="admin@fleet.com",
                     hashed_password=hash_password("Admin@1234"),
                     role=UserRole.admin, phone="+91-9000000001"),
                User(full_name="Dispatcher Priya", email="dispatcher@fleet.com",
                     hashed_password=hash_password("Disp@1234"),
                     role=UserRole.dispatcher, phone="+91-9000000002"),
                User(full_name="Driver Rajan", email="driver1@fleet.com",
                     hashed_password=hash_password("Driver@1234"),
                     role=UserRole.driver, phone="+91-9000000003"),
                User(full_name="Driver Sunita", email="driver2@fleet.com",
                     hashed_password=hash_password("Driver@1234"),
                     role=UserRole.driver, phone="+91-9000000004"),
            ]
            db.add_all(users)
            db.commit()
            logger.info("✅ Users seeded")

        # ── Vehicles ──────────────────────────────────────────────────────────
        if db.query(Vehicle).count() == 0:
            now = datetime.now(timezone.utc)
            vehicles = [
                Vehicle(vehicle_id="TRK-001", registration_number="TS-09-AA-1234",
                        vehicle_type=VehicleType.truck, make="Tata", model="Prima",
                        year=2021, capacity=20, fuel_level=85.0, fuel_status=FuelStatus.full,
                        mileage=45000, maintenance_status=MaintenanceStatus.good,
                        next_maintenance_due=now + timedelta(days=60), is_available=True),
                Vehicle(vehicle_id="BUS-001", registration_number="TS-09-BB-5678",
                        vehicle_type=VehicleType.bus, make="Volvo", model="9400",
                        year=2020, capacity=48, fuel_level=35.0, fuel_status=FuelStatus.low,
                        mileage=120000, maintenance_status=MaintenanceStatus.due_soon,
                        next_maintenance_due=now + timedelta(days=8), is_available=True),
                Vehicle(vehicle_id="VAN-001", registration_number="TS-09-CC-9012",
                        vehicle_type=VehicleType.van, make="Force", model="Traveller",
                        year=2022, capacity=12, fuel_level=60.0, fuel_status=FuelStatus.adequate,
                        mileage=28000, maintenance_status=MaintenanceStatus.good,
                        next_maintenance_due=now + timedelta(days=90), is_available=True),
                Vehicle(vehicle_id="TRK-002", registration_number="TS-09-DD-3456",
                        vehicle_type=VehicleType.truck, make="Ashok Leyland", model="Boss",
                        year=2019, capacity=15, fuel_level=10.0, fuel_status=FuelStatus.critical,
                        mileage=89000, maintenance_status=MaintenanceStatus.overdue,
                        next_maintenance_due=now - timedelta(days=5), is_available=True),
            ]
            db.add_all(vehicles)
            db.commit()
            logger.info("✅ Vehicles seeded")

        # ── Routes ────────────────────────────────────────────────────────────
        if db.query(Route).count() == 0:
            routes = [
                Route(route_code="RT-HYD-MUM", name="Hyderabad to Mumbai Express",
                      origin="Hyderabad", destination="Mumbai",
                      waypoints='["Pune", "Nashik"]',
                      distance_km=711.0, estimated_duration_hours=12.5),
                Route(route_code="RT-HYD-BLR", name="Hyderabad to Bangalore Corridor",
                      origin="Hyderabad", destination="Bangalore",
                      waypoints='["Kurnool", "Anantapur"]',
                      distance_km=570.0, estimated_duration_hours=9.0),
                Route(route_code="RT-HYD-CHN", name="Hyderabad to Chennai Highway",
                      origin="Hyderabad", destination="Chennai",
                      waypoints='["Nellore", "Vijayawada"]',
                      distance_km=625.0, estimated_duration_hours=10.5),
            ]
            db.add_all(routes)
            db.commit()
            logger.info("✅ Routes seeded")

        # ── Sample trip ───────────────────────────────────────────────────────
        if db.query(Trip).count() == 0:
            now = datetime.now(timezone.utc)
            vehicle = db.query(Vehicle).filter(Vehicle.vehicle_id == "TRK-001").first()
            driver = db.query(User).filter(User.email == "driver1@fleet.com").first()
            route = db.query(Route).filter(Route.route_code == "RT-HYD-MUM").first()
            dispatcher = db.query(User).filter(User.email == "dispatcher@fleet.com").first()

            trip = Trip(
                trip_code="TRIP-DEMO-0001",
                vehicle_id=vehicle.id,
                driver_id=driver.id,
                route_id=route.id,
                dispatcher_id=dispatcher.id,
                status=TripStatus.scheduled,
                scheduled_departure=now + timedelta(hours=2),
                scheduled_arrival=now + timedelta(hours=14),
                cargo_description="Electronic components",
                cargo_weight_kg=5000.0,
            )
            db.add(trip)
            vehicle.is_available = False
            db.commit()
            logger.info("✅ Sample trip seeded")

        logger.info("\n🚀 Database seeded successfully!")
        logger.info("─────────────────────────────────────")
        logger.info("Test credentials:")
        logger.info("  Admin:      admin@fleet.com      / Admin@1234")
        logger.info("  Dispatcher: dispatcher@fleet.com / Disp@1234")
        logger.info("  Driver:     driver1@fleet.com    / Driver@1234")
        logger.info("─────────────────────────────────────")

    except Exception as e:
        db.rollback()
        logger.error(f"Seeding failed: {e}")
        raise
    finally:
        db.close()


if __name__ == "__main__":
    seed()
