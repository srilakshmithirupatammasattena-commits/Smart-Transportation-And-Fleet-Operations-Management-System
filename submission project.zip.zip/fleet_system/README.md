# 🚚 Smart Transportation & Fleet Operations Management System

[![Python](https://img.shields.io/badge/Python-3.11+-blue.svg)](https://python.org)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.111-green.svg)](https://fastapi.tiangolo.com)
[![PostgreSQL](https://img.shields.io/badge/PostgreSQL-15-blue.svg)](https://postgresql.org)
[![JWT](https://img.shields.io/badge/Auth-JWT-orange.svg)](https://jwt.io)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

A **production-grade backend system** for managing vehicle fleets, routes, trips, and operational workflows — built with FastAPI, PostgreSQL, and JWT-based RBAC.

---

## 📐 System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    CLIENT (Postman / Frontend)                   │
└───────────────────────┬─────────────────────────────────────────┘
                        │ HTTPS REST
┌───────────────────────▼─────────────────────────────────────────┐
│                  FastAPI Application Layer                        │
│  ┌─────────────┐  ┌──────────────┐  ┌───────────────────────┐  │
│  │  JWT Auth   │  │  RBAC Guards │  │  Request Middleware   │  │
│  │  Middleware │  │  (3 Roles)   │  │  (Logging, CORS)      │  │
│  └─────────────┘  └──────────────┘  └───────────────────────┘  │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │                    API Endpoints (Router)                  │  │
│  │  /auth  /users  /vehicles  /routes  /trips  /alerts       │  │
│  │  /reports                                                  │  │
│  └─────────────────────────┬─────────────────────────────────┘  │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │                    Service Layer                           │  │
│  │  AuthService │ VehicleService │ TripService │ AlertService│  │
│  │  RouteService │ ReportService                             │  │
│  └─────────────────────────┬─────────────────────────────────┘  │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │                SQLAlchemy ORM Models                       │  │
│  │  User │ Vehicle │ Route │ Trip │ TripLog │ Alert          │  │
│  └─────────────────────────┬─────────────────────────────────┘  │
└─────────────────────────────┼───────────────────────────────────┘
                              │
┌─────────────────────────────▼───────────────────────────────────┐
│                       PostgreSQL 15                              │
│   users │ vehicles │ routes │ trips │ trip_logs │ alerts        │
└─────────────────────────────────────────────────────────────────┘
```

### Design Decisions
| Concern | Choice | Reason |
|---|---|---|
| Framework | FastAPI | Async-ready, auto OpenAPI docs, Pydantic validation |
| Database | PostgreSQL | ACID compliance, rich querying, production-proven |
| Auth | JWT (access + refresh) | Stateless, scalable, no server-side sessions |
| Password hashing | bcrypt | Industry standard, adaptive cost factor |
| ORM | SQLAlchemy 2.0 | Type-safe, supports async, Alembic migrations |
| Logging | Loguru | Structured logs, rotation, beautiful output |

---

## 🗂 Project Structure

```
fleet_system/
├── app/
│   ├── main.py                  # FastAPI app factory, middleware, startup
│   ├── core/
│   │   ├── config.py            # Pydantic settings (env vars)
│   │   └── security.py          # JWT, bcrypt, role dependencies
│   ├── db/
│   │   └── database.py          # SQLAlchemy engine, session, init_db
│   ├── models/                  # SQLAlchemy ORM models
│   │   ├── user.py              # User + UserRole enum
│   │   ├── vehicle.py           # Vehicle + enums
│   │   ├── route.py             # Route
│   │   ├── trip.py              # Trip + TripLog + TripStatus
│   │   └── alert.py             # Alert + AlertType + Severity
│   ├── schemas/                 # Pydantic request/response models
│   │   ├── user.py
│   │   ├── vehicle.py
│   │   ├── route.py
│   │   ├── trip.py
│   │   └── alert.py             # Alerts + Report schemas
│   ├── services/                # Business logic layer
│   │   ├── auth_service.py      # Register, login, token refresh
│   │   ├── vehicle_service.py   # CRUD, fuel/maintenance logic
│   │   ├── route_service.py     # CRUD, active-trip safety check
│   │   ├── trip_service.py      # State machine, audit logging
│   │   └── alert_service.py     # Alert CRUD, auto-scan, reports
│   └── api/
│       ├── __init__.py          # Master router
│       └── endpoints/
│           ├── auth.py
│           ├── users.py
│           ├── vehicles.py
│           ├── routes.py
│           ├── trips.py
│           └── alerts.py        # Alerts + Reports routers
├── tests/
│   └── test_api.py              # 25+ unit/integration tests
├── scripts/
│   └── seed_db.py               # Demo data seeder
├── logs/                        # Auto-created at runtime
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
├── alembic.ini
├── .env.example
└── FleetManagement_Postman.json # Import into Postman
```

---

## ⚡ Quick Start

### Option 1: Docker Compose (Recommended — zero config)

```bash
git clone https://github.com/yourname/fleet-management-system.git
cd fleet-management-system

# Start PostgreSQL + API
docker-compose up --build -d

# Seed demo data
docker-compose exec api python -m scripts.seed_db

# Open API docs
open http://localhost:8000/api/docs
```

### Option 2: Local Setup (PostgreSQL required)

```bash
# 1. Clone and enter
git clone https://github.com/yourname/fleet-management-system.git
cd fleet-management-system

# 2. Python virtual environment
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment
cp .env.example .env
# Edit .env and set DATABASE_URL (or use SQLite for quick testing)
# For SQLite: DATABASE_URL=sqlite:///./fleet.db

# 5. Run the server (auto-creates tables)
uvicorn app.main:app --reload --port 8000

# 6. Seed demo data
python -m scripts.seed_db

# 7. Visit API docs
open http://localhost:8000/api/docs
```

### Option 3: SQLite (No database setup needed)

Edit `.env`:
```
DATABASE_URL=sqlite:///./fleet.db
```
Then follow steps 5–7 above.

---

## 🔑 Authentication

The system uses **JWT Bearer tokens**. All endpoints (except `/api/auth/login`) require:
```
Authorization: Bearer <your_access_token>
```

### Seeded Demo Accounts
| Role | Email | Password |
|---|---|---|
| **Admin** | admin@fleet.com | Admin@1234 |
| **Dispatcher** | dispatcher@fleet.com | Disp@1234 |
| **Driver** | driver1@fleet.com | Driver@1234 |

### Get a token
```bash
curl -X POST http://localhost:8000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "admin@fleet.com", "password": "Admin@1234"}'
```

---

## 🛡 Role-Based Access Control (RBAC)

| Endpoint Category | Admin | Dispatcher | Driver |
|---|:---:|:---:|:---:|
| Register users | ✅ | ❌ | ❌ |
| Manage vehicles (CRUD) | ✅ | ❌ | ❌ |
| View vehicles | ✅ | ✅ | ✅ |
| Create/edit trips | ✅ | ✅ | ❌ |
| Update trip status | ✅ | ✅ | Own only |
| View all trips | ✅ | ✅ | Own only |
| Manage routes | ✅ | ❌ | ❌ |
| View routes | ✅ | ✅ | ✅ |
| Create alerts | ✅ | ✅ | ✅ |
| Resolve alerts | ✅ | ✅ | ❌ |
| View reports | ✅ | ✅ | ❌ |

---

## 📡 API Endpoints Reference

### Authentication — `/api/auth`
| Method | Endpoint | Auth | Description |
|---|---|---|---|
| POST | `/auth/login` | None | Login, get JWT tokens |
| POST | `/auth/register` | Admin | Register new user |
| GET | `/auth/me` | Any | Get current user profile |
| POST | `/auth/refresh` | None | Refresh access token |
| POST | `/auth/logout` | Any | Logout (client-side) |

### Users — `/api/users`
| Method | Endpoint | Auth | Description |
|---|---|---|---|
| GET | `/users` | Admin | List all users |
| GET | `/users/drivers` | Admin | List all drivers |
| GET | `/users/{id}` | Admin/Own | Get user by ID |
| PUT | `/users/{id}` | Admin | Update user |
| DELETE | `/users/{id}` | Admin | Deactivate user |

### Vehicles — `/api/vehicles`
| Method | Endpoint | Auth | Description |
|---|---|---|---|
| GET | `/vehicles` | Any | List vehicles (filterable) |
| POST | `/vehicles` | Admin | Add vehicle |
| GET | `/vehicles/{id}` | Any | Get vehicle details |
| PUT | `/vehicles/{id}` | Admin | Update vehicle |
| DELETE | `/vehicles/{id}` | Admin | Delete vehicle |
| PATCH | `/vehicles/{id}/fuel` | Admin/Dispatcher | Update fuel level |
| GET | `/vehicles/maintenance-due` | Admin/Dispatcher | Vehicles needing maintenance |

### Routes — `/api/routes`
| Method | Endpoint | Auth | Description |
|---|---|---|---|
| GET | `/routes` | Any | List routes |
| POST | `/routes` | Admin | Create route |
| GET | `/routes/{id}` | Any | Get route |
| PUT | `/routes/{id}` | Admin | Update route |
| DELETE | `/routes/{id}` | Admin | Delete route |

### Trips — `/api/trips`
| Method | Endpoint | Auth | Description |
|---|---|---|---|
| GET | `/trips` | Any | List trips (role-filtered) |
| POST | `/trips` | Admin/Dispatcher | Create trip |
| GET | `/trips/my-trips` | Driver | My assigned trips |
| GET | `/trips/{id}` | Any | Trip details + logs |
| PUT | `/trips/{id}` | Admin/Dispatcher | Edit trip |
| PATCH | `/trips/{id}/status` | Any | Update trip status |
| GET | `/trips/{id}/logs` | Admin/Dispatcher | Audit log |

### Alerts — `/api/alerts`
| Method | Endpoint | Auth | Description |
|---|---|---|---|
| GET | `/alerts` | Admin/Dispatcher | List alerts |
| POST | `/alerts` | Any | Report alert |
| PATCH | `/alerts/{id}/resolve` | Admin/Dispatcher | Resolve alert |
| POST | `/alerts/auto-scan` | Admin | Auto-detect fleet issues |

### Reports — `/api/reports`
| Method | Endpoint | Auth | Description |
|---|---|---|---|
| GET | `/reports/fleet-summary` | Admin/Dispatcher | Real-time fleet dashboard |
| GET | `/reports/daily-performance` | Admin/Dispatcher | Daily trip KPIs |

---

## 🔄 Trip State Machine

```
         ┌─────────────┐
         │  SCHEDULED  │◄──────────────────────────────────┐
         └──────┬──────┘                                   │
                │ Start trip                               │
         ┌──────▼──────┐         Delay reported            │
         │ IN_PROGRESS │──────────────────────►┌──────────┐│
         └──────┬──────┘                       │ DELAYED  ││
                │                              └────┬─────┘│
                │ Completed                         │ Back on track
         ┌──────▼──────┐◄──────────────────────────┘
         │  COMPLETED  │  (terminal — vehicle freed)
         └─────────────┘

         ┌─────────────┐
         │  CANCELLED  │  (terminal — vehicle freed)
         └─────────────┘
         Any non-terminal state can transition to CANCELLED.
```

---

## 🧪 Running Tests

```bash
# Run all tests with coverage
pytest tests/ -v --cov=app --cov-report=term-missing

# Run specific test class
pytest tests/test_api.py::TestTrips -v

# Run with HTML coverage report
pytest tests/ --cov=app --cov-report=html
open htmlcov/index.html
```

Tests use **SQLite in-memory** — no Postgres needed for testing.

---

## 🚀 Deployment

### Railway (Easiest)
```bash
npm install -g @railway/cli
railway login
railway init
railway add postgresql
railway up
```

### Render
1. Create new Web Service → connect GitHub repo
2. Build command: `pip install -r requirements.txt`
3. Start command: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
4. Add env var: `DATABASE_URL` from Render Postgres

### AWS EC2
```bash
# On EC2 (Ubuntu)
sudo apt update && sudo apt install -y python3-pip postgresql nginx
pip install -r requirements.txt
# Set env vars in /etc/environment
uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 4
```

---

## 📦 Import Postman Collection

1. Open Postman → **Import**
2. Select `FleetManagement_Postman.json`
3. Run **"Login as Admin"** first → token auto-stored in collection variable
4. All other requests use `{{adminToken}}` automatically

---

## 🔒 Security Features

- **bcrypt password hashing** with auto-salting (cost factor 12)
- **JWT access tokens** (60 min expiry) + **refresh tokens** (7 days)
- **RBAC** enforced at every endpoint via FastAPI dependencies
- **Input validation** via Pydantic v2 with strict type checking
- **SQL injection prevention** via SQLAlchemy ORM parameterized queries
- **CORS** configured with allowed origins
- **Global error handler** — never exposes stack traces to clients
- **Request logging** with timing for audit trails

---

## 📊 Database Schema

```
users           vehicles         routes
─────────       ────────         ──────
id (PK)         id (PK)          id (PK)
full_name       vehicle_id       route_code
email           registration_no  name
hashed_pwd      vehicle_type     origin
role            capacity         destination
phone           fuel_level       waypoints
is_active       fuel_status      distance_km
                mileage          est_duration
                maintenance_*    is_active
                is_available

trips                   trip_logs         alerts
─────                   ─────────         ──────
id (PK)                 id (PK)           id (PK)
trip_code               trip_id (FK)      alert_type
vehicle_id (FK)         actor_id (FK)     severity
driver_id (FK)          event             vehicle_id (FK)
route_id (FK)           detail            trip_id (FK)
dispatcher_id (FK)      created_at        reported_by (FK)
status                                    message
scheduled_departure                       is_resolved
scheduled_arrival                         resolved_at
actual_departure
actual_arrival
fuel_used_liters
distance_covered_km
delay_minutes
delay_reason
```

---

## 🛠 Tech Stack

| Layer | Technology |
|---|---|
| Language | Python 3.11+ |
| Framework | FastAPI 0.111 |
| Database | PostgreSQL 15 / SQLite (dev) |
| ORM | SQLAlchemy 2.0 |
| Auth | python-jose (JWT) + passlib (bcrypt) |
| Validation | Pydantic v2 |
| Logging | Loguru |
| Testing | pytest + TestClient |
| Container | Docker + Docker Compose |
| Migrations | Alembic |

---

## 👨‍💻 Author

Built as a full-stack backend engineering assessment demonstrating:
- Clean architecture (controller → service → model separation)
- Secure RBAC with stateless JWT
- Production-ready error handling and logging
- Comprehensive test coverage
- Docker-ready deployment setup
