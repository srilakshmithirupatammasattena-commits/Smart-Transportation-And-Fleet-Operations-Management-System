from datetime import datetime, timezone
from typing import Optional
from sqlalchemy.orm import Session
from fastapi import HTTPException
from loguru import logger

from app.models.route import Route
from app.schemas.route import RouteCreate, RouteUpdate


class RouteService:

    @staticmethod
    def create(db: Session, data: RouteCreate) -> Route:
        if db.query(Route).filter(Route.route_code == data.route_code).first():
            raise HTTPException(status_code=400, detail=f"Route code '{data.route_code}' already exists")
        route = Route(**data.model_dump())
        db.add(route)
        db.commit()
        db.refresh(route)
        logger.info(f"Route created: {route.route_code}")
        return route

    @staticmethod
    def get_all(db: Session, skip: int = 0, limit: int = 50,
                active_only: bool = False) -> tuple[list[Route], int]:
        query = db.query(Route)
        if active_only:
            query = query.filter(Route.is_active == True)
        total = query.count()
        return query.offset(skip).limit(limit).all(), total

    @staticmethod
    def get_by_id(db: Session, route_id: int) -> Route:
        r = db.query(Route).filter(Route.id == route_id).first()
        if not r:
            raise HTTPException(status_code=404, detail=f"Route {route_id} not found")
        return r

    @staticmethod
    def update(db: Session, route_id: int, data: RouteUpdate) -> Route:
        r = RouteService.get_by_id(db, route_id)
        for field, value in data.model_dump(exclude_unset=True).items():
            setattr(r, field, value)
        r.updated_at = datetime.now(timezone.utc)
        db.commit()
        db.refresh(r)
        logger.info(f"Route {r.route_code} updated")
        return r

    @staticmethod
    def delete(db: Session, route_id: int) -> dict:
        r = RouteService.get_by_id(db, route_id)
        from app.models.trip import Trip, TripStatus
        active = db.query(Trip).filter(
            Trip.route_id == route_id,
            Trip.status.in_([TripStatus.scheduled, TripStatus.in_progress])
        ).count()
        if active:
            raise HTTPException(status_code=409,
                                detail="Cannot delete route with active/scheduled trips")
        db.delete(r)
        db.commit()
        return {"message": f"Route {r.route_code} deleted successfully"}
