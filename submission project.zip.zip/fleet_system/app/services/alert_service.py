from datetime import datetime, timezone, date, timedelta
from typing import Optional
from sqlalchemy.orm import Session
from sqlalchemy import func
from fastapi import HTTPException
from loguru import logger

from app.models.alert import Alert, AlertSeverity
from app.models.vehicle import Vehicle, FuelStatus, MaintenanceStatus
from app.models.trip import Trip, TripStatus
from app.schemas.alert import AlertCreate, AlertResolve, FleetSummaryReport, TripPerformanceReport


class AlertService:

    @staticmethod
    def create(db: Session, data: AlertCreate, reported_by: int) -> Alert:
        # Validate references
        if data.vehicle_id:
            if not db.query(Vehicle).filter(Vehicle.id == data.vehicle_id).first():
                raise HTTPException(status_code=404, detail="Vehicle not found")
        if data.trip_id:
            if not db.query(Trip).filter(Trip.id == data.trip_id).first():
                raise HTTPException(status_code=404, detail="Trip not found")

        alert = Alert(**data.model_dump(), reported_by=reported_by)
        db.add(alert)
        db.commit()
        db.refresh(alert)
        logger.warning(f"Alert created: {alert.alert_type} severity={alert.severity}")
        return alert

    @staticmethod
    def get_all(db: Session, skip: int = 0, limit: int = 50,
                unresolved_only: bool = False,
                severity: Optional[AlertSeverity] = None) -> tuple[list[Alert], int]:
        query = db.query(Alert)
        if unresolved_only:
            query = query.filter(Alert.is_resolved == False)
        if severity:
            query = query.filter(Alert.severity == severity)
        total = query.count()
        return query.order_by(Alert.created_at.desc()).offset(skip).limit(limit).all(), total

    @staticmethod
    def resolve(db: Session, alert_id: int, data: AlertResolve) -> Alert:
        a = db.query(Alert).filter(Alert.id == alert_id).first()
        if not a:
            raise HTTPException(status_code=404, detail="Alert not found")
        if a.is_resolved:
            raise HTTPException(status_code=400, detail="Alert already resolved")
        a.is_resolved = True
        a.resolved_at = datetime.now(timezone.utc)
        a.resolution_note = data.resolution_note
        db.commit()
        db.refresh(a)
        logger.info(f"Alert {alert_id} resolved")
        return a

    @staticmethod
    def auto_generate_alerts(db: Session) -> list[Alert]:
        """Scan fleet and auto-create system alerts for fuel/maintenance issues."""
        generated = []
        # Low fuel alerts
        low_fuel_vehicles = db.query(Vehicle).filter(
            Vehicle.fuel_status.in_([FuelStatus.low, FuelStatus.critical]),
            Vehicle.is_available == True
        ).all()
        for v in low_fuel_vehicles:
            exists = db.query(Alert).filter(
                Alert.vehicle_id == v.id,
                Alert.alert_type == "fuel_low",
                Alert.is_resolved == False
            ).first()
            if not exists:
                from app.models.alert import AlertType
                a = Alert(
                    alert_type=AlertType.fuel_low,
                    severity=AlertSeverity.critical if v.fuel_status.value == "critical" else AlertSeverity.high,
                    vehicle_id=v.id,
                    message=f"Vehicle {v.vehicle_id} fuel level at {v.fuel_level:.1f}% — {v.fuel_status.value}",
                )
                db.add(a)
                generated.append(a)

        # Maintenance overdue alerts
        overdue = db.query(Vehicle).filter(
            Vehicle.maintenance_status == MaintenanceStatus.overdue
        ).all()
        for v in overdue:
            from app.models.alert import AlertType
            exists = db.query(Alert).filter(
                Alert.vehicle_id == v.id,
                Alert.alert_type == AlertType.maintenance_due,
                Alert.is_resolved == False
            ).first()
            if not exists:
                a = Alert(
                    alert_type=AlertType.maintenance_due,
                    severity=AlertSeverity.high,
                    vehicle_id=v.id,
                    message=f"Vehicle {v.vehicle_id} maintenance is OVERDUE (due: {v.next_maintenance_due})",
                )
                db.add(a)
                generated.append(a)

        db.commit()
        logger.info(f"Auto-generated {len(generated)} alerts")
        return generated


class ReportService:

    @staticmethod
    def daily_trip_performance(db: Session, report_date: Optional[date] = None) -> TripPerformanceReport:
        target = report_date or datetime.now(timezone.utc).date()
        start = datetime(target.year, target.month, target.day, tzinfo=timezone.utc)
        end = start + timedelta(days=1)

        trips = db.query(Trip).filter(
            Trip.scheduled_departure >= start,
            Trip.scheduled_departure < end,
        ).all()

        total = len(trips)
        completed = sum(1 for t in trips if t.status == TripStatus.completed)
        delayed = sum(1 for t in trips if t.status == TripStatus.delayed)
        cancelled = sum(1 for t in trips if t.status == TripStatus.cancelled)
        in_progress = sum(1 for t in trips if t.status == TripStatus.in_progress)
        scheduled = sum(1 for t in trips if t.status == TripStatus.scheduled)

        delay_vals = [t.delay_minutes for t in trips if t.delay_minutes]
        avg_delay = sum(delay_vals) / len(delay_vals) if delay_vals else 0.0
        total_dist = sum(t.distance_covered_km or 0 for t in trips)
        total_fuel = sum(t.fuel_used_liters or 0 for t in trips)
        on_time_pct = (completed / total * 100) if total > 0 else 0.0

        return TripPerformanceReport(
            report_date=target,
            total_trips=total,
            completed_trips=completed,
            delayed_trips=delayed,
            cancelled_trips=cancelled,
            in_progress_trips=in_progress,
            scheduled_trips=scheduled,
            avg_delay_minutes=round(avg_delay, 2),
            total_distance_km=round(total_dist, 2),
            total_fuel_used_liters=round(total_fuel, 2),
            on_time_percentage=round(on_time_pct, 2),
        )

    @staticmethod
    def fleet_summary(db: Session) -> FleetSummaryReport:
        total_vehicles = db.query(Vehicle).count()
        available = db.query(Vehicle).filter(Vehicle.is_available == True).count()
        in_maint = db.query(Vehicle).filter(
            Vehicle.maintenance_status == MaintenanceStatus.in_maintenance
        ).count()
        low_fuel = db.query(Vehicle).filter(
            Vehicle.fuel_status.in_([FuelStatus.low, FuelStatus.critical])
        ).count()

        from app.models.route import Route
        active_trips = db.query(Trip).filter(
            Trip.status.in_([TripStatus.in_progress, TripStatus.scheduled])
        ).count()
        active_routes = db.query(Route).filter(Route.is_active == True).count()
        open_alerts = db.query(Alert).filter(Alert.is_resolved == False).count()
        critical_alerts = db.query(Alert).filter(
            Alert.is_resolved == False,
            Alert.severity == AlertSeverity.critical
        ).count()

        return FleetSummaryReport(
            report_generated_at=datetime.now(timezone.utc),
            total_vehicles=total_vehicles,
            available_vehicles=available,
            vehicles_in_maintenance=in_maint,
            vehicles_with_low_fuel=low_fuel,
            total_active_trips=active_trips,
            total_active_routes=active_routes,
            open_alerts=open_alerts,
            critical_alerts=critical_alerts,
        )
