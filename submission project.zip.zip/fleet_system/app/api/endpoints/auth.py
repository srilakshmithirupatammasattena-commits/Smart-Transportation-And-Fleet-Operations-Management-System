from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.schemas.user import UserCreate, LoginRequest, TokenResponse, UserResponse, RefreshTokenRequest
from app.services.auth_service import AuthService
from app.core.security import get_current_user, require_admin

router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED,
             summary="Register a new user (Admin only)")
def register(
    data: UserCreate,
    db: Session = Depends(get_db),
    _current_user=Depends(require_admin),
):
    """
    Create a new user account. Only admins can register new users.
    Roles available: admin | dispatcher | driver
    """
    return AuthService.register_user(db, data, created_by_role=_current_user.role)


@router.post("/login", response_model=TokenResponse, summary="Login and receive JWT tokens")
def login(data: LoginRequest, db: Session = Depends(get_db)):
    """Authenticate with email + password and receive access + refresh tokens."""
    return AuthService.authenticate(db, data)


@router.post("/refresh", summary="Refresh access token")
def refresh_token(data: RefreshTokenRequest, db: Session = Depends(get_db)):
    """Exchange a valid refresh token for a new access token."""
    return AuthService.refresh_access_token(db, data.refresh_token)


@router.get("/me", response_model=UserResponse, summary="Get current user profile")
def get_me(current_user=Depends(get_current_user)):
    """Return the profile of the currently authenticated user."""
    return current_user


@router.post("/logout", summary="Logout (client-side token discard)")
def logout():
    """
    Logout endpoint. Since we use stateless JWT, the client must discard the token.
    For production, implement a token blocklist (e.g., Redis).
    """
    return {"message": "Logged out successfully. Please discard your tokens on the client side."}
