"""Initial migration - create all tables

Revision ID: 001_initial
Revises: 
Create Date: 2026-04-05 00:00:00.000000
"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = "001_initial"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # ── users ──────────────────────────────────────────────────────────────
    op.create_table(
        "users",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("full_name", sa.String(120), nullable=False),
        sa.Column("email", sa.String(255), nullable=False),
        sa.Column("hashed_password", sa.String(255), nullable=False),
        sa.Column("role", sa.Enum("admin", "dispatcher", "driver", name="userrole"), nullable=False),
        sa.Column("phone", sa.String(20), nullable=True),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default="true"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()")),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_users_id", "users", ["id"])
    op.create_index("ix_users_email", "users", ["email"], unique=True)

    # ── vehicles ───────────────────────────────────────────────────────────
    op.create_table(
        "vehicles",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("vehicle_id", sa.String(50), nullable=False),
        sa.Column("registration_number", sa.String(50), nullable=False),
        sa.Column("vehicle_type", sa.Enum("truck", "bus", "van", "car", name="vehicletype"), nullable=False),
        sa.Column("make", sa.String(80), nullable=True),
        sa.Column("model", sa.String(80), nullable=True),
        sa.Column("year", sa.Integer(), nullable=True),
        sa.Column("capacity", sa.Integer(), nullable=False),
        sa.Column("fuel_level", sa.Float(), server_default="100.0"),
        sa.Column("fuel_status", sa.Enum("full", "adequate", "low", "critical", name="fuelstatus"),
                  server_default="full"),
        sa.Column("mileage", sa.Float(), server_default="0.0"),
        sa.Column("last_maintenance_date", sa.DateTime(timezone=True), nullable=True),
        sa.Column("next_maintenance_due", sa.DateTime(timezone=True), nullable=True),
        sa.Column("maintenance_status",
                  sa.Enum("good", "due_soon", "overdue", "in_maintenance", name="maintenancestatus"),
                  server_default="good"),
        sa.Column("is_available", sa.Boolean(), server_default="true"),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()")),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_vehicles_id", "vehicles", ["id"])
    op.create_index("ix_vehicles_vehicle_id", "vehicles", ["vehicle_id"], unique=True)

    # ── routes ─────────────────────────────────────────────────────────────
    op.create_table(
        "routes",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("route_code", sa.String(50), nullable=False),
        sa.Column("name", sa.String(200), nullable=False),
        sa.Column("origin", sa.String(200), nullable=False),
        sa.Column("destination", sa.String(200), nullable=False),
        sa.Column("waypoints", sa.Text(), nullable=True),
        sa.Column("distance_km", sa.Float(), nullable=False),
        sa.Column("estimated_duration_hours", sa.Float(), nullable=False),
        sa.Column("is_active", sa.Boolean(), server_default="true"),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()")),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_routes_id", "routes", ["id"])
    op.create_index("ix_routes_route_code", "routes", ["route_code"], unique=True)

    # ── trips ──────────────────────────────────────────────────────────────
    op.create_table(
        "trips",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("trip_code", sa.String(50), nullable=False),
        sa.Column("vehicle_id", sa.Integer(), sa.ForeignKey("vehicles.id"), nullable=False),
        sa.Column("driver_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("route_id", sa.Integer(), sa.ForeignKey("routes.id"), nullable=False),
        sa.Column("dispatcher_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("status",
                  sa.Enum("scheduled", "in_progress", "completed", "delayed", "cancelled",
                          name="tripstatus"),
                  server_default="scheduled"),
        sa.Column("scheduled_departure", sa.DateTime(timezone=True), nullable=False),
        sa.Column("scheduled_arrival", sa.DateTime(timezone=True), nullable=False),
        sa.Column("actual_departure", sa.DateTime(timezone=True), nullable=True),
        sa.Column("actual_arrival", sa.DateTime(timezone=True), nullable=True),
        sa.Column("cargo_description", sa.String(500), nullable=True),
        sa.Column("cargo_weight_kg", sa.Float(), nullable=True),
        sa.Column("passengers", sa.Integer(), nullable=True),
        sa.Column("fuel_used_liters", sa.Float(), nullable=True),
        sa.Column("distance_covered_km", sa.Float(), nullable=True),
        sa.Column("delay_minutes", sa.Integer(), server_default="0"),
        sa.Column("delay_reason", sa.Text(), nullable=True),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("is_active", sa.Boolean(), server_default="true"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()")),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_trips_id", "trips", ["id"])
    op.create_index("ix_trips_trip_code", "trips", ["trip_code"], unique=True)

    # ── trip_logs ──────────────────────────────────────────────────────────
    op.create_table(
        "trip_logs",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("trip_id", sa.Integer(), sa.ForeignKey("trips.id"), nullable=False),
        sa.Column("actor_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("event", sa.String(100), nullable=False),
        sa.Column("detail", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()")),
        sa.PrimaryKeyConstraint("id"),
    )

    # ── alerts ─────────────────────────────────────────────────────────────
    op.create_table(
        "alerts",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("alert_type",
                  sa.Enum("delay", "breakdown", "fuel_low", "maintenance_due",
                          "accident", "route_deviation", name="alerttype"),
                  nullable=False),
        sa.Column("severity",
                  sa.Enum("low", "medium", "high", "critical", name="alertseverity"),
                  server_default="medium"),
        sa.Column("vehicle_id", sa.Integer(), sa.ForeignKey("vehicles.id"), nullable=True),
        sa.Column("trip_id", sa.Integer(), sa.ForeignKey("trips.id"), nullable=True),
        sa.Column("reported_by", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("message", sa.Text(), nullable=False),
        sa.Column("is_resolved", sa.Boolean(), server_default="false"),
        sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("resolution_note", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()")),
        sa.PrimaryKeyConstraint("id"),
    )


def downgrade() -> None:
    op.drop_table("alerts")
    op.drop_table("trip_logs")
    op.drop_table("trips")
    op.drop_table("routes")
    op.drop_table("vehicles")
    op.drop_table("users")
    # Drop enums (PostgreSQL specific)
    for enum_name in ["userrole", "vehicletype", "fuelstatus", "maintenancestatus",
                      "tripstatus", "alerttype", "alertseverity"]:
        op.execute(f"DROP TYPE IF EXISTS {enum_name}")
