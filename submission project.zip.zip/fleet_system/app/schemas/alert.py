from pydantic import BaseModel, Field
from datetime import datetime, date
from typing import Optional
from app.models.alert import AlertType, AlertSeverity


class AlertCreate(BaseModel):
    alert_type: AlertType
    severity: AlertSeverity = AlertSeverity.medium
    vehicle_id: Optional[int] = None
    trip_id: Optional[int] = None
    message: str = Field(..., min_length=5, max_length=1000)


class AlertResolve(BaseModel):
    resolution_note: str = Field(..., min_length=5)


class AlertResponse(BaseModel):
    id: int
    alert_type: AlertType
    severity: AlertSeverity
    vehicle_id: Optional[int]
    trip_id: Optional[int]
    reported_by: Optional[int]
    message: str
    is_resolved: bool
    resolved_at: Optional[datetime]
    resolution_note: Optional[str]
    created_at: datetime

    model_config = {"from_attributes": True}


class AlertListResponse(BaseModel):
    total: int
    alerts: list[AlertResponse]


# ─── Report schemas ───────────────────────────────────────────────────────────

class TripPerformanceReport(BaseModel):
    report_date: date
    total_trips: int
    completed_trips: int
    delayed_trips: int
    cancelled_trips: int
    in_progress_trips: int
    scheduled_trips: int
    avg_delay_minutes: float
    total_distance_km: float
    total_fuel_used_liters: float
    on_time_percentage: float


class VehicleUtilizationReport(BaseModel):
    vehicle_id: str
    vehicle_type: str
    total_trips: int
    completed_trips: int
    total_distance_km: float
    total_fuel_used: float
    avg_fuel_per_trip: float
    maintenance_status: str
    is_available: bool


class FleetSummaryReport(BaseModel):
    report_generated_at: datetime
    total_vehicles: int
    available_vehicles: int
    vehicles_in_maintenance: int
    vehicles_with_low_fuel: int
    total_active_trips: int
    total_active_routes: int
    open_alerts: int
    critical_alerts: int
