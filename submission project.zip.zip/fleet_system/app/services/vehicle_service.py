from datetime import datetime, timezone
from typing import Optional
from sqlalchemy.orm import Session
from fastapi import HTTPException, status
from loguru import logger

from app.models.vehicle import Vehicle, FuelStatus, MaintenanceStatus
from app.schemas.vehicle import VehicleCreate, VehicleUpdate, FuelUpdateRequest


def _compute_fuel_status(level: float) -> FuelStatus:
    if level >= 75:
        return FuelStatus.full
    elif level >= 40:
        return FuelStatus.adequate
    elif level >= 15:
        return FuelStatus.low
    return FuelStatus.critical


def _compute_maintenance_status(next_due: Optional[datetime]) -> MaintenanceStatus:
    if next_due is None:
        return MaintenanceStatus.good
    now = datetime.now(timezone.utc)
    delta_days = (next_due - now).days
    if delta_days < 0:
        return MaintenanceStatus.overdue
    elif delta_days <= 14:
        return MaintenanceStatus.due_soon
    return MaintenanceStatus.good


class VehicleService:

    @staticmethod
    def create(db: Session, data: VehicleCreate) -> Vehicle:
        if db.query(Vehicle).filter(Vehicle.vehicle_id == data.vehicle_id).first():
            raise HTTPException(status_code=400, detail=f"Vehicle ID '{data.vehicle_id}' already exists")
        if db.query(Vehicle).filter(Vehicle.registration_number == data.registration_number).first():
            raise HTTPException(status_code=400, detail=f"Registration '{data.registration_number}' already exists")

        vehicle = Vehicle(
            **data.model_dump(exclude={"fuel_level"}),
            fuel_level=data.fuel_level,
            fuel_status=_compute_fuel_status(data.fuel_level),
            maintenance_status=_compute_maintenance_status(data.next_maintenance_due),
        )
        db.add(vehicle)
        db.commit()
        db.refresh(vehicle)
        logger.info(f"Vehicle created: {vehicle.vehicle_id}")
        return vehicle

    @staticmethod
    def get_all(db: Session, skip: int = 0, limit: int = 50,
                vehicle_type: Optional[str] = None,
                available_only: bool = False) -> tuple[list[Vehicle], int]:
        query = db.query(Vehicle)
        if vehicle_type:
            query = query.filter(Vehicle.vehicle_type == vehicle_type)
        if available_only:
            query = query.filter(Vehicle.is_available == True)
        total = query.count()
        return query.offset(skip).limit(limit).all(), total

    @staticmethod
    def get_by_id(db: Session, vehicle_id: int) -> Vehicle:
        v = db.query(Vehicle).filter(Vehicle.id == vehicle_id).first()
        if not v:
            raise HTTPException(status_code=404, detail=f"Vehicle {vehicle_id} not found")
        return v

    @staticmethod
    def update(db: Session, vehicle_id: int, data: VehicleUpdate) -> Vehicle:
        v = VehicleService.get_by_id(db, vehicle_id)
        update_data = data.model_dump(exclude_unset=True)

        for field, value in update_data.items():
            setattr(v, field, value)

        # Recompute derived statuses
        if "fuel_level" in update_data:
            v.fuel_status = _compute_fuel_status(v.fuel_level)
        if "next_maintenance_due" in update_data:
            v.maintenance_status = _compute_maintenance_status(v.next_maintenance_due)

        v.updated_at = datetime.now(timezone.utc)
        db.commit()
        db.refresh(v)
        logger.info(f"Vehicle {v.vehicle_id} updated")
        return v

    @staticmethod
    def delete(db: Session, vehicle_id: int) -> dict:
        v = VehicleService.get_by_id(db, vehicle_id)
        # Safety: don't delete vehicles with active trips
        from app.models.trip import Trip, TripStatus
        active = db.query(Trip).filter(
            Trip.vehicle_id == vehicle_id,
            Trip.status.in_([TripStatus.scheduled, TripStatus.in_progress])
        ).count()
        if active:
            raise HTTPException(status_code=409,
                                detail="Cannot delete vehicle with active/scheduled trips")
        db.delete(v)
        db.commit()
        logger.info(f"Vehicle {v.vehicle_id} deleted")
        return {"message": f"Vehicle {v.vehicle_id} deleted successfully"}

    @staticmethod
    def update_fuel(db: Session, vehicle_id: int, data: FuelUpdateRequest) -> Vehicle:
        v = VehicleService.get_by_id(db, vehicle_id)
        v.fuel_level = data.fuel_level
        v.fuel_status = _compute_fuel_status(data.fuel_level)
        v.updated_at = datetime.now(timezone.utc)
        db.commit()
        db.refresh(v)
        logger.info(f"Vehicle {v.vehicle_id} fuel updated to {data.fuel_level}%")
        return v

    @staticmethod
    def get_maintenance_due(db: Session) -> list[Vehicle]:
        """Return vehicles with overdue or due_soon maintenance."""
        return db.query(Vehicle).filter(
            Vehicle.maintenance_status.in_([
                MaintenanceStatus.overdue,
                MaintenanceStatus.due_soon,
                MaintenanceStatus.in_maintenance
            ])
        ).all()
